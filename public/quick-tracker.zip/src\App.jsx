import React, { useState, useEffect, useRef } from 'react'
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Save, 
  Clock, 
  ChevronDown, 
  CheckCircle2, 
  History, 
  ExternalLink,
  Settings,
  MoreVertical,
  X
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import axios from 'axios'
import { clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

function cn(...inputs) {
  return twMerge(clsx(inputs))
}

const API_BASE = '/api' // Proxied in vite.config.js

export default function App() {
  // State
  const [time, setTime] = useState(0)
  const [isRunning, setIsRunning] = useState(false)
  const [taskName, setTaskName] = useState('')
  const [selectedProject, setSelectedProject] = useState(null)
  const [projects, setProjects] = useState([])
  const [history, setHistory] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [showHistory, setShowHistory] = useState(false)
  
  const timerRef = useRef(null)

  // Load projects from main API
  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const res = await axios.get(`${API_BASE}/projects`)
        setProjects(res.data)
        if (res.data.length > 0) setSelectedProject(res.data[0])
      } catch (err) {
        console.error("Failed to fetch projects", err)
      }
    }
    fetchProjects()

    // Restore state from localStorage if exists
    const savedTime = localStorage.getItem('tracker_time')
    const savedIsRunning = localStorage.getItem('tracker_running')
    const savedLastTick = localStorage.getItem('tracker_last_tick')

    if (savedTime) setTime(parseInt(savedTime))
    if (savedIsRunning === 'true' && savedLastTick) {
      const elapsedSinceLastTick = Math.floor((Date.now() - parseInt(savedLastTick)) / 1000)
      setTime(prev => prev + elapsedSinceLastTick)
      setIsRunning(true)
    }
  }, [])

  // Timer logic
  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setTime(prev => {
          const next = prev + 1
          localStorage.setItem('tracker_time', next)
          localStorage.setItem('tracker_last_tick', Date.now().toString())
          return next
        })
      }, 1000)
    } else {
      clearInterval(timerRef.current)
      localStorage.setItem('tracker_running', 'false')
    }
    return () => clearInterval(timerRef.current)
  }, [isRunning])

  useEffect(() => {
    localStorage.setItem('tracker_running', isRunning)
  }, [isRunning])

  // Formatting helpers
  const formatTime = (seconds) => {
    const hrs = Math.floor(seconds / 3600)
    const mins = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  // Handlers
  const handleStartStop = () => setIsRunning(!isRunning)
  
  const handleReset = () => {
    if (window.confirm("Are you sure you want to reset the timer?")) {
      setIsRunning(false)
      setTime(0)
      localStorage.removeItem('tracker_time')
      localStorage.removeItem('tracker_last_tick')
    }
  }

  const handleSave = async () => {
    if (!taskName.trim()) {
      alert("Please enter what you're working on.")
      return
    }
    if (!selectedProject) {
      alert("Please select a project.")
      return
    }

    setIsLoading(true)
    try {
      const hours = (time / 3600).toFixed(2)
      const date = new Date().toISOString().split('T')[0]
      
      const res = await axios.post(`${API_BASE}/tasks`, {
        title: taskName,
        project: selectedProject.name,
        loggedHours: hours,
        loggedDate: date,
        status: 'completed',
        priority: 'medium'
      })

      // Add to local history
      const newEntry = {
        id: Date.now(),
        taskTitle: taskName,
        projectName: selectedProject.name,
        timeSpent: formatTime(time),
        timestamp: new Date().toLocaleTimeString()
      }
      setHistory([newEntry, ...history])

      // Reset
      setIsRunning(false)
      setTime(0)
      setTaskName('')
      localStorage.removeItem('tracker_time')
      alert("Task logged successfully!")
    } catch (err) {
      alert("Failed to save task: " + (err.response?.data?.message || err.message))
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="w-full max-w-md overflow-hidden glass rounded-3xl shadow-2xl relative"
      >
        {/* Header */}
        <div className="px-6 py-5 flex items-center justify-between border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-accent-purple to-accent-blue flex items-center justify-center shadow-lg shadow-accent-purple/20">
              <Clock className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight">Quick Tracker</h1>
              <p className="text-xs text-white/40 font-medium">System Sync Active</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setShowHistory(!showHistory)}
              className="p-2 rounded-lg hover:bg-white/5 transition-colors text-white/60 hover:text-white"
            >
              <History className="w-5 h-5" />
            </button>
            <button className="p-2 rounded-lg hover:bg-white/5 transition-colors text-white/60 hover:text-white">
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="p-6 space-y-6">
          {/* Timer Display */}
          <div className="relative py-8 flex flex-col items-center">
            <motion.div 
              animate={isRunning ? { scale: [1, 1.02, 1] } : {}}
              transition={{ duration: 2, repeat: Infinity }}
              className="timer-text text-7xl font-extrabold text-white tracking-tighter drop-shadow-2xl"
            >
              {formatTime(time)}
            </motion.div>
            <div className="mt-2 flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10">
              <div className={cn("w-2 h-2 rounded-full", isRunning ? "bg-accent-cyan animate-pulse" : "bg-white/20")} />
              <span className="text-[10px] uppercase tracking-widest font-bold text-white/50">
                {isRunning ? "Tracking Active" : "Paused"}
              </span>
            </div>
          </div>

          {/* Controls */}
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={handleStartStop}
              className={cn(
                "flex items-center justify-center gap-2 py-4 rounded-2xl font-bold transition-all active:scale-95",
                isRunning 
                  ? "bg-white/5 text-white border border-white/10 hover:bg-white/10" 
                  : "bg-accent-purple text-white shadow-xl shadow-accent-purple/20 hover:shadow-accent-purple/40"
              )}
            >
              {isRunning ? (
                <>
                  <Pause className="w-5 h-5 fill-current" />
                  <span>Pause</span>
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 fill-current" />
                  <span>Start Tracking</span>
                </>
              )}
            </button>
            <button 
              onClick={handleReset}
              className="flex items-center justify-center gap-2 py-4 rounded-2xl font-bold bg-white/5 text-white border border-white/10 hover:bg-white/10 transition-all active:scale-95"
            >
              <RotateCcw className="w-5 h-5" />
              <span>Reset</span>
            </button>
          </div>

          {/* Form */}
          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-white/40 uppercase tracking-wider ml-1">Current Task</label>
              <input 
                type="text" 
                placeholder="What are you working on?"
                value={taskName}
                onChange={(e) => setTaskName(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder:text-white/20 outline-none focus:border-accent-purple/50 focus:bg-white/10 transition-all"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-white/40 uppercase tracking-wider ml-1">Select Project</label>
              <div className="relative group">
                <select 
                  value={selectedProject?.id || ''}
                  onChange={(e) => {
                    const p = projects.find(p => p.id === parseInt(e.target.value))
                    setSelectedProject(p)
                  }}
                  className="w-full appearance-none bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white outline-none focus:border-accent-purple/50 focus:bg-white/10 transition-all cursor-pointer"
                >
                  {projects.length === 0 && <option>No projects found</option>}
                  {projects.map(p => (
                    <option key={p.id} value={p.id} className="bg-content">{p.name}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40 pointer-events-none group-hover:text-white/60 transition-colors" />
              </div>
            </div>

            <button 
              onClick={handleSave}
              disabled={isLoading || time < 60} // Require at least 1 min to save usually
              className={cn(
                "w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95 mt-4 disabled:opacity-50 disabled:cursor-not-allowed",
                "bg-gradient-to-r from-accent-purple to-accent-cyan text-white shadow-xl shadow-accent-purple/10"
              )}
            >
              {isLoading ? (
                <div className="w-6 h-6 border-2 border-white/20 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Save className="w-5 h-5" />
                  <span>Sync to Server</span>
                </>
              )}
            </button>
            {time < 60 && !isLoading && (
              <p className="text-[10px] text-center text-white/20 font-medium">Tracking must be at least 1 minute to sync.</p>
            )}
          </div>
        </div>

        {/* Footer info */}
        <div className="px-6 py-4 bg-white/5 flex items-center justify-between">
          <div className="flex -space-x-2">
            {[1,2,3].map(i => (
              <div key={i} className="w-6 h-6 rounded-full bg-content border-2 border-background flex items-center justify-center">
                <div className="w-3 h-3 rounded-full bg-accent-purple/40" />
              </div>
            ))}
            <div className="pl-4 text-[10px] text-white/40 font-bold flex items-center">
              5 COLLEAGUES ONLINE
            </div>
          </div>
          <a href="http://localhost:5173" className="text-[10px] font-bold text-accent-cyan flex items-center gap-1 hover:underline">
            OPEN SYSTEM <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        {/* Side Tray: History */}
        <AnimatePresence>
          {showHistory && (
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="absolute inset-0 bg-content z-20 flex flex-col"
            >
              <div className="p-6 flex items-center justify-between border-b border-white/5">
                <h2 className="font-bold text-lg flex items-center gap-2">
                  <History className="w-5 h-5 text-accent-purple" />
                  Recent Activity
                </h2>
                <button 
                  onClick={() => setShowHistory(false)}
                  className="p-2 rounded-lg hover:bg-white/5"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-auto p-4 space-y-3">
                {history.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-white/20">
                    <History className="w-12 h-12 mb-2 opacity-10" />
                    <p className="font-bold uppercase tracking-widest text-[10px]">No logs yet</p>
                  </div>
                ) : (
                  history.map(item => (
                    <div key={item.id} className="p-4 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-bold">{item.taskTitle}</h4>
                        <div className="flex items-center gap-2 text-[10px] text-white/40 font-bold uppercase tracking-wider">
                          <span>{item.projectName}</span>
                          <span>•</span>
                          <span>{item.timestamp}</span>
                        </div>
                      </div>
                      <div className="text-sm font-bold text-accent-cyan">
                        {item.timeSpent}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  )
}
